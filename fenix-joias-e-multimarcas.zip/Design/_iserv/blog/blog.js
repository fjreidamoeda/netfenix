function showComments(paraid, addFormOnly, closed){
	var fieldclass = 'input-xlarge';
	try {
		var content = $('#blg_'+paraid).html();
		if ( ( content != '' ) && ( ( addFormOnly && content.search( '<!--ADDCOMMENT-->' ) != -1 ) || ( !addFormOnly && content.search( '<!--COMMENTS-->' ) != -1 ) ) ) {
			$('#blg_'+paraid).html('');
			return false;
		}
		fieldValues = getBlogCookie( "dcbb8c17" );
		fieldArray  = fieldValues.split("\|");
		var postForm;
		if (closed) {
			postForm = '<hr><span>Comentarios encerados</span>';
		}
		else {
			postForm = '<form class="form-horizontal" action="" method="post" id="c_form'+paraid+'" name="c_form'+paraid+'"><legend>Postar um comentario</legend>';
			postForm +=
					'<div class="control-group">' +
					'<label class="control-label required" for="c_name' + paraid + '"><span style="color: #ff0000">*</span>Seu Nome</label>' +
					'<div class="controls">' + 
					'<input class="'+fieldclass+'" name="author" id="c_name' + paraid + '" type="text" maxlength="50" value="' + ( ( fieldArray[ 0 ] != null ) ? fieldArray[ 0 ] : '' ) + '">' +
					'</div>' +
					'</div>';
			postForm +=
					'<div class="control-group">' +
					'<label class="control-label" for="c_mail' + paraid + '">Seu e-mail</label>' +
					'<div class="controls">' + 
					'<input class="'+fieldclass+'" name="email" id="c_mail' + paraid + '" type="text" maxlength="255" value="' + ( ( fieldArray[ 1 ] != null ) ? fieldArray[ 1 ].replace( '.at.chez.', '@' ) : '' ) + '">' +
					'</div>' +
					'</div>';
			postForm +=
					'<div class="control-group">' +
					'<label class="control-label" for="c_site' + paraid + '">Seu site</label>' +
					'<div class="controls">' + 
					'<input class="'+fieldclass+'" name="url" id="c_site' + paraid + '" type="text" maxlength="255" value="' + ( ( fieldArray[ 2 ] != null ) ? fieldArray[ 2 ] : 'http://' ) + '">' +
					'</div>' +
					'</div>';
			postForm +=
					'<div class="control-group">' +
					'<label class="control-label required" for="c_content' + paraid + '"><span style="color: #ff0000">*</span>Sua mensagem</label>' +
					'<div class="controls">' + 
					'<textarea ' +
						'class="'+fieldclass+'" name="text" id="c_content' + paraid + '" type="text" maxlength="' + 2000 + '" value="' + ( ( fieldArray[ 0 ] != null ) ? fieldArray[ 0 ] : '' ) + 
						'rows="10" onkeypress="javascript:if(this.value.length > 2000) this.value = this.value.substring(0, 2000);">' +
						'</textarea>' +
					'</div>' +
					'</div>';
					
					
			postForm +=
					'<div class="control-group">' +
					'<label class="control-label" for="addc_' + paraid + '">&nbsp;</label>' +
					'<div class="controls">' + 
						'<a class="btn" name="op" id="addc_' + paraid + '" href="javascript:postComment(\'' + paraid + '\')">Enviar</a>' +
						'<span style="display:block;font-size:80%"><span style="color:#ff0000;">*</span>Campo de preenchimento obrigatorio</span>' +
					'</div>' +
					'</div>';
			postForm +=
					'<input type="hidden" name="" value="">';
					
			postForm +=
				'</form>' +
				'<iframe id="AddCom_IFrame" name="AddCom_IFrame" style="width:0px; height:0px; border: 0px"></iframe>';
		}
		capHTML = '';
		
		if ( addFormOnly ) {
			$('#blg_'+paraid).html( postForm.replace( 'CAP_HTML', capHTML ) + '<!--ADDCOMMENT-->' );
		} else if (window.XSLTProcessor && window.XMLHttpRequest) {
			var xmlDoc;
			var xslStylesheet;
			var xsltProcessor = new XSLTProcessor();
			var myXMLHTTPRequest = new XMLHttpRequest();
			myXMLHTTPRequest.open("GET", '_iserv/blog/blog.xsl', false);
			myXMLHTTPRequest.send(null);
			xslStylesheet = myXMLHTTPRequest.responseXML;
			xsltProcessor.importStylesheet(xslStylesheet);
			myXMLHTTPRequest = new XMLHttpRequest();
			myXMLHTTPRequest.open("GET", '_iserv/blog/data/' + paraid + '.xml', false);
			myXMLHTTPRequest.send(null);
			xmlDoc = myXMLHTTPRequest.responseXML;
			var doc = xsltProcessor.transformToDocument(xmlDoc);
			var xmls = new XMLSerializer();
			$('#blg_'+paraid).html( xmls.serializeToString(doc) + postForm.replace( 'CAP_HTML', capHTML )  + '<!--COMMENTS-->' );
		} else if (window.ActiveXObject || "ActiveXObject" in window) {
			var xmlDoc;
			var xslDoc;
			try {
			  xmlDoc = new ActiveXObject('Msxml2.XMLDOM');
			} catch (e) {
			  xmlDoc = new ActiveXObject('Microsoft.XMLDOM');
			}
			try {
			  xslDoc = new ActiveXObject('Msxml2.XMLDOM');
			} catch (e) {
			  xslDoc = new ActiveXObject('Microsoft.XMLDOM');
			}
			xmlDoc.async = false;
			xmlDoc.load('_iserv/blog/data/' + paraid + '.xml');
			xslDoc.async = false;
			xslDoc.load('_iserv/blog/blog.xsl');
			$('#blg_'+paraid).html( xmlDoc.transformNode(xslDoc) + postForm.replace( 'CAP_HTML', capHTML ) + '<!--COMMENTS-->' );
		}
		
	} catch (e) {
	  return e;
	}
}
function getCommentLink(paraid, closed, divalign) {
	try {
		var req, n = 0, r = 0;
		if (window.XSLTProcessor && window.XMLHttpRequest) {
			try {
				req = new XMLHttpRequest();
				req.open("GET",'_iserv/blog/data/' + paraid + '.txt', false);
				req.send(null);
			} catch (e) {
				n = 0;
			}
		} else if (window.ActiveXObject || "ActiveXObject" in window) {
			try {
				var req;
				try {
					req = new ActiveXObject('Msxml2.XMLHTTP');
				} catch (e) {
					req = new ActiveXObject('Microsoft.XMLHTTP');
				}
				req.open("GET", '_iserv/blog/data/' + paraid + '.txt?__' + encodeURIComponent((new Date()).getTime()), false);
				req.send(null);
			} catch (e) {
				n = 0;
			}
		}
		try {
			var spl = req.responseText.split( '|' );
			n = parseInt( spl[ 0 ] );
			
			if ( isNaN( n ) ) n = 0;
		} catch (e) {
			n = 0;
		}
		if( divalign==null )
			divalign = 'right';
		var raty = '';
		
		divalign = (divalign=='right')?'left':'right';
		var comAnchor;
		if(n>1)
			comAnchor = '%n comentarios';
		else
			comAnchor = '%n comentario';
		var shtml = ''; 
		if(n>0)
			shtml += raty + '<a style="background: url(_iserv/blog/blog-comments.gif) no-repeat; background-position:'+divalign+' center; padding:0 20px 1px 20px;" ' +
							'href="javascript:showComments(\'' + paraid + '\', false, ' + closed + ');">' + comAnchor.replace( "%n", n ) + 
							'</a>';
		if(closed)
			;
		else
			shtml += '<a style="background: url(_iserv/blog/blog-addcomment.gif) no-repeat; background-position:'+divalign+' center; padding:0 20px 1px 20px;" ' +
					 'href="javascript:showComments(\'' + paraid + '\', true, ' + closed + ');">Postar um comentario</a>';
		$('#blg_' + paraid ).html( shtml );
		
	} catch (e) {
		alert(e);
	}
}
var inPostComment = false;
function postComment(paraid) {
	if ( inPostComment ) return;
	var errors='';
	var author = $('#c_name'+paraid).val();
	var email = $('#c_mail'+paraid).val();
	var url = $('#c_site'+paraid).val();
	var text = $('#c_content'+paraid).val();
	var blankRE = /^\s*$/;
	if (blankRE.test(author)) {
		errors = '- Erro campo do nome vazio\n';
	}
	else {
		var illegalChars = /\W/;
		if (illegalChars.test(author.replace(/-/g, "").replace(/\x20/g, ""))) {
			errors = errors + '- Erro campo do nome invalído\n';
		}
	}
	var isAdmin = hex_md5(author) == '21232f297a57a5a743894a0e4a801fc3';
	if ( isAdmin ) {
		var re = /^(DEL|MOD)[1-9]([0-9])*$/;
		var isBlankUrl = blankRE.test(url) || url == 'http://';
		if( !isBlankUrl && !re.test(url) ) {
			errors = errors + '- Inválido comando administrativo, o campo url deve estar vazio para postar ou contém um comando \"DELn\" ou \"MODn\" com \"n\", como o índice da mensagem a moderada (' + url + ')\n';
		}
		else {
			if( ( isBlankUrl || url.indexOf( 'MOD' ) != -1 ) && blankRE.test(text)) {
				errors = errors + '- Erro campo messagem vazio\n';
			}
		}
	}
	else {
		var re = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(email.length != 0  && !re.test(email)) {
			errors = errors + '- Erro campo do e-mail invalído\n';
		}
		re = /(http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		if(url.length != 0 && url != 'http://' && !re.test(url)) {
			errors = errors + '- Erro campo do site invalído\n';
		}
		if (blankRE.test(text)) {
			errors = errors + '- Erro campo messagem vazio\n';
		}
		if (text.length > 2000 ) {
			errors = errors + '- Erro campo  mensagem muito voluminoso (2000 max.)\n';
		}
		
	}
	if(errors.length > 0) {
		errors = 'Desculpe os campos estão incorrectos:\n\n' + errors;
		alert( errors );
		return;
	}
	alert("Visualização local : você não pode usar la función de blog a partir da visualização local do seu site, mas apenas a partir da versão publicada."); return;
	if( isAdmin )
		setBlogCookie( "dcbb8c17", author + '\|' + email.replace( '@', '.at.chez.' ) + '\|' );
	else
		setBlogCookie( "dcbb8c17", author + '\|' + email.replace( '@', '.at.chez.' ) + '\|' + url, 180 );
	inPostComment = true;
	var form = document.getElementById('c_form'+paraid);
	form.action='xuBiHAjYxUvYTofYRiKiWOVYrEhagijE' + paraid;
	form.target='AddCom_IFrame';
	form.submit();
}
function setBlogCookie(c_name,value,expiredays) {
	var exdate=new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString())+";path=/";
}
function getBlogCookie(c_name) {
	if (document.cookie.length>0) {
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1) { 
			c_start=c_start + c_name.length+1; 
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end));
	    } 
	}
	return "";
}
