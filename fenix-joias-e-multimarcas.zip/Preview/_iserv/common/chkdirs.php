<?php
	@require_once("../common/com.php");
	checkAllIServDataDirs( "../", true );
?>
