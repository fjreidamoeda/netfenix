<?php
	@require 'ipenv.php';
	echo PMA_getIP();
?>

